




---
aliases: []
type: meeting
project: Project01
cdate: 2022-03-20 12:53 
mdate: Sunday 20th March 2022 12:53:41 
---

# Attendees
- [[Person One]]
- [[Person Two]]
...

# Agenda
What is plannend.

# Notes
What happend

# Outcome
Next steps...